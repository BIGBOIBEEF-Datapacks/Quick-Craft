package com.bigboibeef.quickcraft.commands;

import com.bigboibeef.quickcraft.QuickCraft;
import com.mojang.brigadier.Command;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.minecraft.command.argument.EntityArgumentType;

public class mode {
    public static void register() {
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(
                    ClientCommandManager.literal("qc")
                            .then(
                                    ClientCommandManager.literal("mode")
                                            .then(
                                                    ClientCommandManager.literal("single")
                                                            .executes(context -> {
                                                                QuickCraft.single = true;
                                                                return Command.SINGLE_SUCCESS;
                                                            })
                                            )
                                            .then(
                                                    ClientCommandManager.literal("stack")
                                                            .executes(context -> {
                                                                QuickCraft.single = false;
                                                                return Command.SINGLE_SUCCESS;
                                                            })
                                            )
                            )

            );
        });
    }
}